$(document).ready(function() {
 
	 // img-popup activation
	 $('.btn').magnificPopup({
	   type: 'image'
	});


	 // video2 activation
	 $('.btn2').magnificPopup({
	   type: 'iframe',
	});

	 // video2 activation
	 $('.btn3').magnificPopup({
	   type: 'iframe',
	});
});